FOUJI MUNDA WEBSITE STARTER
===========================

Files:
- index.html: responsive Hindi/English starter website. No build tools required.

Preview:
1. Unzip the package.
2. Open index.html in a browser.

Before publishing:
1. Replace the YouTube button URL with your exact channel URL.
2. Replace the contact email placeholder with an email you control.
3. Add real, original articles and images; cite official sources for recruitment updates.
4. Create proper Privacy Policy, Disclaimer and Contact pages before applying for advertising.
5. Do not present this site as an official Indian Army or government website.

Low-budget launch:
- Buy a domain from a reputable registrar (often roughly ₹700–₹1,500/year depending on extension and offers).
- Hosting can be free for a static site using GitHub Pages or Cloudflare Pages; a custom domain still costs money.
- Upload index.html to your hosting provider and connect your domain.
- AdSense approval and earnings are not guaranteed; publish useful original content and follow its current policies.

Official recruitment source:
https://joinindianarmy.nic.in/
